// src/environments/environment.ts
export const environment = {
    production: false,
    usersAPIURL: 'http://localhost:5000/api/',
    productsAPIURL: 'http://localhost:6001/api/products/',
    ordersAPIURL: 'http://localhost:7000/api/orders/',
  };
