﻿namespace eCommerce.OrdersService.BusinessLogicLayer.RabbitMQ
{
  public interface IRabbitMQProductNameUpdateConsumer
  {
    void Consume();
  }
}