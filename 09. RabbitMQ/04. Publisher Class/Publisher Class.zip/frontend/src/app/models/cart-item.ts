export interface CartItem {
    productID: string;
    productName: string;
    category: string;
    unitPrice: number;
    quantity: number;
}
