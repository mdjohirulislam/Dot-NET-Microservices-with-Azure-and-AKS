export interface NewOrderItemRequest {
    productID: string;
    unitPrice: number;
    quantity: number;
}
