export interface NewProductRequest {
    productName: string;
    category: string;
    unitPrice: number;
    quantityInStock: number;
}
